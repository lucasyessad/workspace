@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM -------------------------------------------------------------------------------
REM SCHEDULE   : YHMECR1                           JOB : YHMECR10.bat
REM TITRE      : CHARGEMENT DES ECARTS EXPLIQUES V4/V5
REM DATE CREA  : 12/03/2026                        USER : UFLULY
REM -------------------------------------------------------------------------------
REM FREQUENCE  : A LA DEMANDE
REM DEPENDANCE : ECART_JUSTIF_V4_V5*.CSV
REM -------------------------------------------------------------------------------
REM CODE RETOUR :
REM   0  = fin normale
REM   10 = aucun fichier a traiter
REM   20 = Erreur
REM   30 = Avertissement (rejet)
REM -------------------------------------------------------------------------------

REM *********** HORS MAESTRO ******************************************************
call \\kenya\dsi\exploit\parmlib\Chemin.bat
REM *********** HORS MAESTRO ******************************************************

set "RC=0"
set "HAS_ERROR=0"

REM =====================================================================
REM PARAMETRES BASE DE DONNEES
REM =====================================================================
set "Server=erm"
set "DataBase=dwh"
set "TS="

REM =====================================================================
REM PARAMETRES MAIL
REM =====================================================================
set "MAIL_CONFIG=%parmlib%\yhm-config-ecart-justif.json"
set "SENDNOTIF_HTML=%proclib%\SendMailNotificationHTML.ps1"
set "TEMPLATE_PATH=%proclib%\template-notification.html"
set "SMTP_SERVER=smtp.fantasia.fr"

REM =====================================================================
REM REPERTOIRES
REM =====================================================================
set "datalib=\\brutus\commun\INEO\DEV\DOR\MigrationLigisV5"
set "SOURCE_DIR=%datalib%\Depot"
set "REF_DIR=%datalib%\referentiel"
set "ARCHIVE_DIR=%datalib%\Archives"
set "LOG_DIR=%loglib%"
set "MASQUE_CSV_FILE=ECART_JUSTIF_V4_V5"

REM =====================================================================
REM SCRIPTS SQL
REM =====================================================================
set "SQLCMD_DIR="
set "SQL_CREATE=%proclib%\yhm_ecart_0_create_all_tables.sql"
set "SQL_LOAD=%proclib%\yhm_ecart_1_load_tmp.sql"
set "SQL_EXTRACT=%proclib%\yhm_ecart_2_extraction_rejets.sql"
set "SQL_INTEG=%proclib%\yhm_ecart_3_integrate_final.sql"

REM =====================================================================
REM HORODATAGE - FORMAT YYYYMMDD_HHMMSS
REM =====================================================================
set TS=%date:~6,4%%date:~3,2%%date:~0,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set TS=%TS: =0%

REM =====================================================================
REM CREATION DES REPERTOIRES
REM =====================================================================
if not exist "%ARCHIVE_DIR%" mkdir "%ARCHIVE_DIR%"
if not exist "%REF_DIR%"     mkdir "%REF_DIR%"

REM =====================================================================
REM NETTOYAGE REPERTOIRE ERREURS (fichiers du run precedent)
REM =====================================================================
echo [INIT] Nettoyage des logs YHM_ECART_JUSTIF precedents...
for %%F in ("%LOG_DIR%\YHM_ECART_JUSTIF_*.*") do del "%%~fF" >nul 2>&1
echo   Fait - Logs YHM_ECART_JUSTIF nettoyes

REM =====================================================================
REM INITIALISATION
REM =====================================================================
set "GLOBAL_ERR_LOG=%LOG_DIR%\YHM_ECART_JUSTIF_ERRORS_!TS!.log"

set "NB_SUCCES=0"
set "NB_ECHEC=0"
set "RAPPORT_LIGNES="

echo ================================================================
echo TRAITEMENT ECARTS JUSTIFIES V4/V5 - [!TS!]
echo ================================================================

REM =====================================================================
REM ETAPE 0 - CREATION TABLES
REM =====================================================================
echo [ETAPE 0/6] Creation / Verification des tables...

sqlcmd -S %Server% -d %DataBase% -E -i "%SQL_CREATE%"
if errorlevel 1 (
    echo   Echec - Erreur creation / verification tables
    set "RC=20"
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 0 - Erreur creation / verification tables^|"
    goto FIN
)

echo   Fait - Tables pretes
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 0 - Tables creees / verifiees^|"

REM =====================================================================
REM ETAPE 1 - RECHERCHE DES FICHIERS
REM =====================================================================
echo [ETAPE 1/6] Recherche fichiers...

if not exist "%SOURCE_DIR%\%MASQUE_CSV_FILE%*.csv" (
    echo   Echec - Aucun fichier a traiter
    set "RC=10"
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 1 - Aucun fichier %MASQUE_CSV_FILE%*.csv a traiter^|"
    goto FIN
)

echo   Fait - Des fichiers ont ete trouves.
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 1 - Fichier(s) detecte(s)^|"

REM =====================================================================
REM TRAITEMENT DES FICHIERS
REM =====================================================================
for %%F in ("%SOURCE_DIR%\%MASQUE_CSV_FILE%*.csv") do (
    call :PROCESS_FILE "%%~fF" "%%~nF" "%%~nxF"
)

if "!HAS_ERROR!"=="1" if "!RC!"=="0" set "RC=20"

REM =====================================================================
REM NETTOYAGE REPERTOIRE LOGS (fichiers YHM_*.log vide - Taille=0)
REM CORRIGE : filtre par prefixe pour ne pas impacter les autres jobs
REM =====================================================================
for %%L in ("%LOG_DIR%\YHM_*.log") do (
    if %%~zL==0 del "%%~fL" >nul 2>&1
)

goto FIN

REM =====================================================================
REM SOUS-ROUTINE TRAITEMENT D'UN FICHIER
REM =====================================================================
:PROCESS_FILE
set "FULL_PATH=%~1"
set "CURRENT_BASE=%~2"
set "CSV_FILE=%~3"
set "FILE_LOG=%LOG_DIR%\YHM_ECART_JUSTIF_%CURRENT_BASE%_LOAD_!TS!.log"
set "INTEG_LOG=%LOG_DIR%\YHM_ECART_JUSTIF_%CURRENT_BASE%_INTEG_!TS!.log"
set "TMP_REJET=%LOG_DIR%\yhm_tmp_rejets_%CURRENT_BASE%_!TS!.csv"
set "TMP_LOAD_LOG=%LOG_DIR%\yhm_tmp_load_%CURRENT_BASE%_!TS!.log"
set "TMP_INTEG_LOG=%LOG_DIR%\yhm_tmp_integ_%CURRENT_BASE%_!TS!.log"

echo --------------------------------------------------------------
echo TRAITEMENT DE : !CSV_FILE!
echo --------------------------------------------------------------

set "RAPPORT_LIGNES=!RAPPORT_LIGNES! ========================= %CSV_FILE% =========================^|"
REM =====================================================================
REM CONVERSION ANSI
REM =====================================================================
echo [ETAPE 2/6] Detection encodage et normalisation ANSI...

powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
    "$p = '!FULL_PATH!'; " ^
    "$b = [IO.File]::ReadAllBytes($p); " ^
    "if ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF) { " ^
    "    $c = [Text.Encoding]::UTF8.GetString($b, 3, $b.Length - 3) " ^
    "} else { " ^
    "    $c = [Text.Encoding]::GetEncoding(1252).GetString($b) " ^
    "}; " ^
    "[IO.File]::WriteAllText($p, $c, [Text.Encoding]::GetEncoding(1252))"

if errorlevel 1 (
    echo   Echec - Echec conversion ANSI [!CSV_FILE!]
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR CONVERSION ANSI : !CSV_FILE!
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 2 - Erreur conversion ANSI^|"
    goto :EOF
)

echo   Fait - Encodage normalise
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 2 - Encodage normalise^|"

REM =====================================================================
REM ETAPE 3 - CHARGEMENT TMP
REM =====================================================================
echo [ETAPE 3/6] Chargement TMP...

if exist "!FILE_LOG!"     del "!FILE_LOG!"     >nul 2>&1
if exist "!TMP_LOAD_LOG!" del "!TMP_LOAD_LOG!" >nul 2>&1

sqlcmd -S %Server% -d %DataBase% -E ^
    -v CSVFILE="!FULL_PATH!" ^
    -i "%SQL_LOAD%" ^
    -o "!TMP_LOAD_LOG!" 2>&1
if errorlevel 1 (
    echo   Echec - Erreur SQL detectee dans le chargement [!CSV_FILE!]
    copy "!TMP_LOAD_LOG!" "!FILE_LOG!" >nul 2>&1
    del  "!TMP_LOAD_LOG!" >nul 2>&1
    echo   Voir details : !FILE_LOG!
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR SQL CHARGEMENT : !CSV_FILE!
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 3 - Erreur SQL chargement^|"
    goto :EOF
)

findstr /I /C:"Msg " /C:"Level " /C:"Incorrect" /C:"Cannot" /C:"Error" "!TMP_LOAD_LOG!" >nul 2>&1
if not errorlevel 1 (
    echo   Echec - Erreur SQL detectee dans le chargement [!CSV_FILE!]
    copy "!TMP_LOAD_LOG!" "!FILE_LOG!" >nul 2>&1
    del  "!TMP_LOAD_LOG!" >nul 2>&1
    echo   Voir details : !FILE_LOG!
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR SQL CHARGEMENT : !CSV_FILE!
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 3 - Erreur SQL chargement^|"
    goto :EOF
)

del "!TMP_LOAD_LOG!" >nul 2>&1
echo   Fait - TMP chargee
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 3 - Chargement TMP^|"

REM =====================================================================
REM ETAPE 4 - EXTRACTION DES REJETS
REM =====================================================================
echo [ETAPE 4/6] Extraction des rejets...

if exist "!TMP_REJET!" del "!TMP_REJET!" >nul 2>&1

sqlcmd -S %Server% -d %DataBase% -E ^
    -i "%SQL_EXTRACT%" ^
    -s ";" -W -h -1 ^
    -o "!TMP_REJET!" 2>> "!FILE_LOG!"

if errorlevel 1 (
    echo   Echec - Erreur technique extraction rejets [!CSV_FILE!]
    set "HAS_ERROR=1"
    set "RC=20"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR EXTRACTION REJETS : !CSV_FILE!
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 4 - Erreur extraction rejets^|"
    goto :EOF
)

set "NB_REJETS=0"

for /f "usebackq tokens=* delims=" %%L in (`findstr /V /I /C:"rows affected" "!TMP_REJET!"`) do (
    set "LINE=%%L"
    if not "!LINE!"=="" set /a NB_REJETS+=1
)

if !NB_REJETS! GTR 0 set /a NB_REJETS-=1

if "!NB_REJETS!"=="0" (
    echo   Fait - Aucun rejet
    del "!TMP_REJET!" >nul 2>&1
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 4 - Aucun rejet detecte^|"
    goto ETAPE_5
)

echo   Echec - !NB_REJETS! ligne(s) en rejet dans !CSV_FILE!
SET "RC=30"
set "REJET_FILE=%LOG_DIR%\YHM_%CURRENT_BASE%_REJET_!TS!.csv"
copy "!TMP_REJET!" "!REJET_FILE!" >nul 2>&1
del  "!TMP_REJET!" >nul 2>&1
echo   Fichier rejet : !REJET_FILE!
set "HAS_ERROR=1"
set /a NB_ECHEC+=1
>> "!GLOBAL_ERR_LOG!" echo REJETS [!NB_REJETS! ligne(s)] : !CSV_FILE! - Voir : !REJET_FILE!
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 4 - Rejets detectes - !NB_REJETS! rejet(s)^|"
goto :EOF

REM =====================================================================
REM ETAPE 5 - INTEGRATION FINALE
REM =====================================================================
:ETAPE_5
echo [ETAPE 5/6] Integration finale...

if exist "!INTEG_LOG!"     del "!INTEG_LOG!"     >nul 2>&1
if exist "!TMP_INTEG_LOG!" del "!TMP_INTEG_LOG!" >nul 2>&1

sqlcmd -S %Server% -d %DataBase% -E ^
    -i "%SQL_INTEG%" ^
    -o "!TMP_INTEG_LOG!" 2>&1
if errorlevel 1 (
    echo   Echec - Erreur SQL detectee dans l'integration [!CSV_FILE!]
    copy "!TMP_INTEG_LOG!" "!INTEG_LOG!" >nul 2>&1
    del  "!TMP_INTEG_LOG!" >nul 2>&1
    echo   Voir details : !INTEG_LOG!
    set "HAS_ERROR=1"
    if "!RC!"=="0" set "RC=20"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR SQL INTEGRATION : !CSV_FILE!
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 5 - Erreur SQL integration^|"
    goto :EOF
)

findstr /I /C:"Msg " /C:"Level " /C:"Incorrect" /C:"Cannot" /C:"Error" "!TMP_INTEG_LOG!" >nul 2>&1
if not errorlevel 1 (
    echo   Echec - Erreur SQL detectee dans l'integration [!CSV_FILE!]
    copy "!TMP_INTEG_LOG!" "!INTEG_LOG!" >nul 2>&1
    del  "!TMP_INTEG_LOG!" >nul 2>&1
    echo   Voir details : !INTEG_LOG!
    set "HAS_ERROR=1"
    if "!RC!"=="0" set "RC=20"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR SQL INTEGRATION : !CSV_FILE!
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 5 - Erreur SQL integration^|"
    goto :EOF
)

del "!TMP_INTEG_LOG!" >nul 2>&1
echo   Fait - Integration terminee
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 5 - Integration finale^|"

REM =====================================================================
REM ETAPE 6 - ARCHIVAGE
REM =====================================================================
echo [ETAPE 6/6] Archivage...

set "ARCHIVE_NAME=%CURRENT_BASE%_!TS!.csv"
move "!FULL_PATH!" "%ARCHIVE_DIR%\!ARCHIVE_NAME!" >nul 2>&1
if errorlevel 1 (
    echo   Echec - Erreur archivage du fichier !CSV_FILE!
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR ARCHIVAGE : !CSV_FILE!
    set "STEP5_LINES=!STEP5_LINES!      | !CSV_FILE! - KO (archivage)^|"
    set "STEP5_HAS_ECHEC=1"
    goto :EOF
)

set /a NB_SUCCES+=1
echo   Fait - Fichier archive : !ARCHIVE_NAME!
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 6 - Integre, table a jour^|"
goto :EOF

REM =====================================================================
REM FIN
REM =====================================================================
:FIN

call :ZIP_SEPARES

echo ================================================================
echo  SYNTHESE
echo    Succes : !NB_SUCCES!
echo    Echecs : !NB_ECHEC!
echo    Code retour : !RC!
echo ================================================================

REM =========================================================================
REM ENVOI DU MAIL HTML - NOUVEAU SYSTEME
REM =========================================================================

set "MAIL_STATUS=SUCCES"
if "!RC!"=="10" set "MAIL_STATUS=AUCUN_FICHIER"
if "!RC!"=="20" set "MAIL_STATUS=ERREUR"
if "!RC!"=="30" set "MAIL_STATUS=WARNING"

REM Creer le ZIP d'erreurs si necessaire
REM if "!HAS_ERROR!"=="1" (
    REM set "ZIP_ERR_RUN=%ARCHIVE_DIR%\YHM_ECART_JUSTIF_ERREURS_!TS!.zip"
	REM set INZIP=!LOG_DIR!\YHM_*.*
	REM echo !INZIP!
	REM call %proclib%\7za.exe a -tzip !ZIP_ERR_RUN! !INZIP! -bd
	
rem    powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
rem        "$f = Get-ChildItem -Path '%LOG_DIR%' -File; " ^
rem        "if ($f) { Compress-Archive -Path $f.FullName -DestinationPath '!ZIP_ERR_RUN!' -Force }"
REM ) else (
    REM set "ZIP_ERR_RUN="
REM )

REM Construire option -Attachments uniquement si le zip existe
set "ATT_OPT="
if not "!ZIP_ERR_RUN!"=="" if exist "!ZIP_ERR_RUN!" set "ATT_OPT=-Attachments ""!ZIP_ERR_RUN!"""

REM Appel du module HTML
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass ^
  -File "%SENDNOTIF_HTML%" ^
  -ConfigFile "%MAIL_CONFIG%" ^
  -Status "!MAIL_STATUS!" ^
  -NomJob "ECART_JUSTIF" ^
  -Horodatage "!TS!" ^
  -KeyValues "Base=%DataBase%;Serveur=%Server%" ^
  -Etapes "!RAPPORT_LIGNES!" ^
  %ATT_OPT%

if errorlevel 1 (
    echo [ERR] Erreur lors de l'envoi du mail
)

exit /b !RC!

REM =====================================================================
REM SOUS-ROUTINE ZIP
REM =====================================================================
:ZIP_SEPARES
echo [ZIP] Creation des archives ZIP...

set "ZIP_VALIDES=%ARCHIVE_DIR%\YHM_ECART_JUSTIF_VALIDES_!TS!.zip"
set "ZIP_ERR_RUN=%ARCHIVE_DIR%\YHM_ECART_JUSTIF_ERREURS_!TS!.zip"

set "HAS_VALIDES=0"
for %%F in ("%ARCHIVE_DIR%\*_!TS!.csv") do set "HAS_VALIDES=1"
if "!HAS_VALIDES!"=="1" (
	set INZIP=!ARCHIVE_DIR!\*_!TS!.csv
	echo !INZIP!
	call %proclib%\7za.exe a -tzip !ZIP_VALIDES! !INZIP! -sdel
    REM powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
        REM "$f = Get-ChildItem -Path '%ARCHIVE_DIR%' -Filter '*_!TS!.csv'; " ^
        REM "if ($f) { Compress-Archive -Path $f.FullName -DestinationPath '!ZIP_VALIDES!' -Force; $f | Remove-Item -Force }"
    if not errorlevel 1 echo   Fait - ZIP VALIDES : !ZIP_VALIDES!
)

set "HAS_ERR=0"
for %%F in ("%LOG_DIR%\*.*") do set "HAS_ERR=1"
if "!HAS_ERR!"=="1" (
    set "ZIP_ERR_RUN=%ARCHIVE_DIR%\YHM_ECART_JUSTIF_ERREURS_!TS!.zip"
	set INZIP=!LOG_DIR!\YHM_*.*
	echo !INZIP!
	call %proclib%\7za.exe a -tzip !ZIP_ERR_RUN! !INZIP! -sdel
    REM powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
        REM "$f = Get-ChildItem -Path '%LOG_DIR%' -File; " ^
        REM "if ($f) { Compress-Archive -Path $f.FullName -DestinationPath '!ZIP_ERR_RUN!' -Force; $f | Remove-Item -Force }"
    if not errorlevel 1 echo   Fait - ZIP ERREURS : !ZIP_ERR_RUN!
) else (
    set "ZIP_ERR_RUN="
)

exit /b 0