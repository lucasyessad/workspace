# ============================================================================
# Send-MailNotification.ps1 - MODULE UNIVERSEL
# ============================================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]  [string]   $ConfigFile,
    [Parameter(Mandatory=$true)]  [string]   $NomJob,
    [Parameter(Mandatory=$true)]  [string]   $Status,
    [string]   $Horodatage   = '',
    [string]   $KeyValues    = '',
    [string]   $Etapes       = '',
    [string]   $MessageLibre = '',
    [string]   $TableCsv     = '',
    [string]   $TableTitle   = '',
    [string]   $SectionFile  = '',
    [string[]] $Attachments  = @()
)

try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

function HtmlEnc([string]$s) {
    if ($null -eq $s) { return '' }
    return [System.Net.WebUtility]::HtmlEncode($s)
}

function Norm-Rcpt([object]$v) {
    if ($null -eq $v) { return @() }
    if ($v -is [System.Array]) {
        return @($v | ForEach-Object { if($_){$_.ToString().Trim()} } | Where-Object { $_ -ne '' })
    }
    return @($v.ToString() -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' })
}

# ---------------------------------------------------------------------------
# Chargement config JSON
# ---------------------------------------------------------------------------
if (-not (Test-Path -LiteralPath $ConfigFile)) { Write-Error "Config not found: $ConfigFile"; exit 1 }

$raw = Get-Content -LiteralPath $ConfigFile -Raw -Encoding UTF8

foreach ($vn in @('TEMPLATE_PATH','SMTP_SERVER','COMPUTERNAME')) {
    $ev = [Environment]::GetEnvironmentVariable($vn)
    if ($ev) { $raw = $raw.Replace('${'+$vn+'}', $ev) }
}

$raw = [regex]::Replace($raw, '(?m)("TemplatePath"\s*:\s*")([^|"]*)(")' , {
    param($m); $p=$m.Groups[2].Value
    if ($p -match '\\' -and $p -notmatch '\\\\') { $p = $p.Replace('\','\\') }
    return "$($m.Groups[1].Value)$p$($m.Groups[3].Value)"
})

try { $cfg = $raw | ConvertFrom-Json -ErrorAction Stop }
catch { Write-Error "JSON parse error: $($_.Exception.Message)"; exit 1 }

foreach ($f in @('SmtpServer','From','To','TemplatePath')) {
    if (-not $cfg.$f) { Write-Error "Missing config: $f"; exit 1 }
}

$SmtpSrv  = $cfg.SmtpServer
$Port     = if ($cfg.Port) { [int]$cfg.Port } else { 25 }
$From     = $cfg.From
$To       = Norm-Rcpt $cfg.To
$Cc       = Norm-Rcpt $cfg.Cc
$TplPath  = $cfg.TemplatePath
$Env_Name = if ($cfg.Environnement) { $cfg.Environnement } else { 'N/A' }
$SubjTpl  = if ($cfg.Subject) { $cfg.Subject } else { '[{{STATUS_LABEL}}] [{{ENVIRONNEMENT}}] {{JOB_NAME}} - {{DATE}}' }
$stMsgs   = $cfg.StatusMessages

# ---------------------------------------------------------------------------
# Template HTML
# ---------------------------------------------------------------------------
if (-not (Test-Path -LiteralPath $TplPath)) { Write-Error "Template not found: $TplPath"; exit 1 }
$tplHtml = Get-Content -LiteralPath $TplPath -Raw -Encoding UTF8

# ---------------------------------------------------------------------------
# Horodatage
# ---------------------------------------------------------------------------
if ($Horodatage -match '^\d{8}_\d{6}$') {
    $dateFmt  = "{0}/{1}/{2}" -f $Horodatage.Substring(6,2),$Horodatage.Substring(4,2),$Horodatage.Substring(0,4)
    $heureFmt = "{0}:{1}:{2}" -f $Horodatage.Substring(9,2),$Horodatage.Substring(11,2),$Horodatage.Substring(13,2)
} else {
    $n = Get-Date; $dateFmt = $n.ToString('dd/MM/yyyy'); $heureFmt = $n.ToString('HH:mm:ss')
    if (-not $Horodatage) { $Horodatage = $n.ToString('yyyyMMdd_HHmmss') }
}

# ---------------------------------------------------------------------------
# Status : label affiche (SUCCES au lieu de OK, ECHEC au lieu de ERREUR)
# ---------------------------------------------------------------------------
$statusLabelMap = @{
    'SUCCES'        = 'SUCCES'
    'ERREUR'        = 'ECHEC'
    'WARNING'       = 'AVERTISSEMENT'
    'INFO'          = 'INFORMATION'
    'AUCUN_FICHIER' = 'AUCUN FICHIER'
}
$statusLabel = if ($statusLabelMap.ContainsKey($Status)) { $statusLabelMap[$Status] } else { $Status }

# Message de statut
$stMsg = $null
if ($stMsgs -and ($stMsgs.PSObject.Properties.Name -contains $Status)) { $stMsg = $stMsgs.$Status }
if ([string]::IsNullOrWhiteSpace($stMsg)) {
    $defaults = @{
        'SUCCES'='Le traitement s''est termine avec succes.'
        'ERREUR'='Une ou plusieurs erreurs sont survenues.'
        'WARNING'='Le traitement s''est termine avec des avertissements.'
        'INFO'='Information transmise par le traitement.'
        'AUCUN_FICHIER'='Aucun fichier a traiter.'
    }
    $stMsg = if ($defaults.ContainsKey($Status)) { $defaults[$Status] } else { "Statut : $Status" }
}

$colorMap = @{ 'SUCCES'='#00A8A8';'ERREUR'='#C0392B';'WARNING'='#D8A825';'INFO'='#2E75B6';'AUCUN_FICHIER'='#6BCFCF' }
$stColor = if ($colorMap.ContainsKey($Status)) { $colorMap[$Status] } else { '#888888' }

# ============================================================================
# RENDERERS DE SECTIONS
# ============================================================================

function Rnd-Kv([array]$items) {
    $h = ''; $alt = $false
    foreach ($p in $items) {
        $bg = if($alt){'#FFFFFF'}else{'#F5F8F8'}
        $h += "<tr><td bgcolor=`"$bg`" style=`"background-color:$bg;padding:9px 22px;`">" +
              "<table width=`"100%`" cellpadding=`"0`" cellspacing=`"0`" border=`"0`"><tr>" +
              "<td width=`"180`" style=`"font-family:Calibri,'Segoe UI',sans-serif;font-size:11px;font-weight:bold;text-transform:uppercase;letter-spacing:0.4px;color:#00A8A8;`">$(HtmlEnc $p[0])</td>" +
              "<td style=`"font-family:Calibri,'Segoe UI',sans-serif;font-size:13px;font-weight:bold;color:#2B2B2B;`">$(HtmlEnc $p[1])</td>" +
              "</tr></table></td></tr>"
        $alt = -not $alt
    }
    return $h
}

function Rnd-Etapes([array]$lines) {
    $h = '<tr><td style="padding:12px 22px;">'
    $h += '<table width="100%" cellpadding="0" cellspacing="0" border="0">'
    $h += '<tr><td style="font-family:Calibri,sans-serif;font-size:10px;font-weight:bold;text-transform:uppercase;letter-spacing:0.6px;color:#2B2B2B;padding-bottom:6px;">Rapport d''ex&eacute;cution</td></tr>'
    $h += '<tr><td height="2" bgcolor="#00A8A8" style="font-size:0;line-height:2px;">&nbsp;</td></tr>'
    $h += '<tr><td height="6" style="font-size:0;">&nbsp;</td></tr>'

    foreach ($l in $lines) {
        $t = $l.Trim(); if (-not $t) { continue }
        $ic = '&#9679;'; $icc = '#888888'; $pad = ''
        if ($t -match '^\[SUCCES\]') { $ic = '&#10003;'; $icc = '#00A8A8' }
        if ($t -match '^\[ECHEC\]')  { $ic = '&#10007;'; $icc = '#C0392B' }
        if ($t -match '^\s*\|')      { $pad = 'padding-left:24px;'; $icc = '#AAAAAA'; $ic = '&#8226;' }
        $h += "<tr><td style=`"font-family:'Courier New',Consolas,monospace;font-size:11px;color:#2B2B2B;padding:3px 0;line-height:1.6;${pad}`"><span style=`"color:${icc};font-size:13px;`">${ic}</span>&nbsp; $(HtmlEnc $t)</td></tr>"
    }
    $h += '</table></td></tr>'
    return $h
}

function Rnd-Table([string]$title, [array]$headers, [array]$rows) {
    $h = '<tr><td style="padding:14px 22px;">'
    if ($title) {
        $h += '<table width="100%" cellpadding="0" cellspacing="0" border="0">'
        $h += "<tr><td style=`"font-family:Calibri,sans-serif;font-size:10px;font-weight:bold;text-transform:uppercase;letter-spacing:0.6px;color:#2B2B2B;padding-bottom:6px;`">$(HtmlEnc $title)</td></tr>"
        $h += '<tr><td height="2" bgcolor="#00A8A8" style="font-size:0;line-height:2px;">&nbsp;</td></tr>'
        $h += '<tr><td height="8" style="font-size:0;">&nbsp;</td></tr></table>'
    }
    $h += '<table width="100%" cellpadding="0" cellspacing="1" border="0" bgcolor="#C8CACA">'
    if ($headers) {
        $h += '<tr>'
        foreach ($hd in $headers) {
            $h += "<td bgcolor=`"#2B2B2B`" style=`"background-color:#2B2B2B;padding:8px 10px;font-family:Calibri,sans-serif;font-size:11px;font-weight:bold;color:#FFFFFF;text-transform:uppercase;letter-spacing:0.3px;`">$(HtmlEnc $hd)</td>"
        }
        $h += '</tr>'
    }
    $alt = $false
    foreach ($r in $rows) {
        $bg = if($alt){'#F7FAFA'}else{'#FFFFFF'}
        $h += '<tr>'
        foreach ($c in $r) {
            $cs = if($c -ne $null){$c.ToString()}else{''}
            $h += "<td bgcolor=`"$bg`" style=`"background-color:$bg;padding:6px 10px;font-family:Calibri,sans-serif;font-size:12px;color:#2B2B2B;`">$(HtmlEnc $cs)</td>"
        }
        $h += '</tr>'
        $alt = -not $alt
    }
    $h += '</table></td></tr>'
    return $h
}

function Rnd-Texte([string]$title, [string]$content) {
    $h = '<tr><td style="padding:12px 22px;">'
    if ($title) {
        $h += '<table width="100%" cellpadding="0" cellspacing="0" border="0">'
        $h += "<tr><td style=`"font-family:Calibri,sans-serif;font-size:10px;font-weight:bold;text-transform:uppercase;letter-spacing:0.6px;color:#2B2B2B;padding-bottom:6px;`">$(HtmlEnc $title)</td></tr>"
        $h += '<tr><td height="2" bgcolor="#00A8A8" style="font-size:0;line-height:2px;">&nbsp;</td></tr>'
        $h += '<tr><td height="8" style="font-size:0;">&nbsp;</td></tr></table>'
    }
    $h += "<div style=`"font-family:Calibri,sans-serif;font-size:13px;color:#2B2B2B;line-height:1.6;`">$(HtmlEnc $content)</div>"
    $h += '</td></tr>'
    return $h
}

# ============================================================================
# ASSEMBLAGE DES SECTIONS
# ============================================================================

$secHtml = ''

# KeyValues
if ($KeyValues) {
    $kvList = @()
    foreach ($pair in ($KeyValues -split ';')) {
        $pts = $pair -split '=',2
        if ($pts.Count -eq 2) { $kvList += ,@($pts[0].Trim(), $pts[1].Trim()) }
    }
    if ($kvList.Count -gt 0) {
        $secHtml += Rnd-Kv $kvList
        $secHtml += '<tr><td height="1" bgcolor="#E0E8E8" style="font-size:0;">&nbsp;</td></tr>'
    }
}

# SectionFile JSON
if ($SectionFile -and (Test-Path -LiteralPath $SectionFile)) {
    try {
        $jSec = Get-Content -LiteralPath $SectionFile -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($s in $jSec) {
            switch ($s.type) {
                'kv'     { $it=@(); foreach($i in $s.items){$it+=,@($i[0],$i[1])}; $secHtml += Rnd-Kv $it }
                'etapes' { $ln=@(); foreach($i in $s.items){$ln+='['+$i[0]+'] '+$i[1]+$(if($i[2]){' - '+$i[2]}else{''})}; $secHtml += Rnd-Etapes $ln }
                'table'  { $rw=@(); foreach($r in $s.rows){$rw+=,@($r)}; $secHtml += Rnd-Table $s.title @($s.headers) $rw }
                'texte'  { $secHtml += Rnd-Texte $s.title $s.content }
            }
        }
    } catch { Write-Warning "SectionFile error: $($_.Exception.Message)" }
}

# TableCsv
if ($TableCsv -and (Test-Path -LiteralPath $TableCsv)) {
    try {
        $csv = Import-Csv -Path $TableCsv -Delimiter ';' -Encoding Default
        if ($csv.Count -gt 0) {
            $hdrs = @($csv[0].PSObject.Properties.Name)
            $rws = @(); foreach($r in $csv) { $rws += ,@($hdrs | ForEach-Object { $r.$_ }) }
            $tt = if($TableTitle){$TableTitle}else{'Donnees'}
            $secHtml += Rnd-Table $tt $hdrs $rws
        }
    } catch { Write-Warning "CSV error: $($_.Exception.Message)" }
}

# Etapes (separateur ^ ou |)
if ($Etapes) {
    $el = @($Etapes -split '[\^|]' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' })
    if ($el.Count -gt 0) { $secHtml += Rnd-Etapes $el }
}

# MessageLibre
if ($MessageLibre) { $secHtml += Rnd-Texte '' $MessageLibre }

# ============================================================================
# REMPLACEMENT PLACEHOLDERS + ENVOI
# ============================================================================

$vars = [ordered]@{
    '{{JOB_NAME}}'       = $NomJob
    '{{STATUS}}'         = $Status
    '{{STATUS_LABEL}}'   = $statusLabel
    '{{DATE}}'           = $dateFmt
    '{{HEURE}}'          = $heureFmt
    '{{STATUS_MESSAGE}}' = $stMsg
    '{{ENVIRONNEMENT}}'  = $Env_Name
    '{{STATUS_COLOR}}'   = $stColor
    '{{SECTIONS}}'       = $secHtml
}

$subj = $SubjTpl
$body = $tplHtml
foreach ($k in $vars.Keys) { $subj = $subj.Replace($k, $vars[$k]); $body = $body.Replace($k, $vars[$k]) }

try {
    $mp = @{
        SmtpServer = $SmtpSrv
        Port       = $Port
        From       = $From
        To         = $To
        Subject    = $subj
        Body       = $body
        BodyAsHtml = $true
        Encoding   = [System.Text.Encoding]::UTF8
        Priority   = 'Normal'
    }
    if ($Cc -and $Cc.Count -gt 0) { $mp.Cc = $Cc }
    $pj = @()
    foreach ($a in $Attachments) {
        if ([string]::IsNullOrWhiteSpace($a)) { continue }
        $at = $a.Trim()
        if (Test-Path -LiteralPath $at) { $pj += $at } else { Write-Warning "Attachment not found: $at" }
    }
    if ($pj.Count -gt 0) { $mp.Attachments = $pj }
    Send-MailMessage @mp
    Write-Output "MAIL_OK"; exit 0
} catch {
    Write-Error "Mail error: $_"
    Write-Output "MAIL_ERROR: $($_.Exception.Message)"; exit 1
}
