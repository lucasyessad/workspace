@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM -------------------------------------------------------------------------------
REM SCHEDULE   : YHMCMP1                           JOB : YHMCMP10.bat
REM TITRE      : COMPARAISON STRUCTURE ET DONNEES V4 VS V5
REM DATE CREA  : 12/03/2026                        USER : UFLULY
REM -------------------------------------------------------------------------------
REM FREQUENCE  : A LA DEMANDE
REM DEPENDANCE : ORT_PARAM_COMPARAISON_V4_V5 (chargee par YHMMAPP1)
REM              ORT_ECART_JUSTIF_V4_V5      (chargee par YHMECRT1)
REM -------------------------------------------------------------------------------
REM CODE RETOUR :
REM   0  = fin normale
REM   10 = aucun fichier a traiter
REM   20 = Erreur
REM   30 = Avertissement (rejet)
REM -------------------------------------------------------------------------------

REM *********** HORS MAESTRO ******************************************************
call \\kenya\dsi\exploit\parmlib\Chemin.bat
REM *********** HORS MAESTRO ******************************************************

set "RC=0"
set "HAS_ERROR=0"

REM =====================================================================
REM PARAMETRES BASE DE DONNEES
REM =====================================================================
set "Server=erm"
set "DataBase=dwh"
set "TS="

REM =====================================================================
REM PARAMETRES MAIL
REM =====================================================================
set "MAIL_CONFIG=%parmlib%\yhm-config-compare.json"
set "SENDNOTIF_HTML=%proclib%\SendMailNotificationHTML.ps1"
set "TEMPLATE_PATH=%proclib%\template-notification.html"
set "SMTP_SERVER=smtp.fantasia.fr"


REM =====================================================================
REM REPERTOIRES
REM =====================================================================
set "datalib=\\brutus\commun\INEO\DEV\DOR\MigrationLigisV5"
set "LOG_DIR=%loglib%"
set "ARCHIVE_DIR=%datalib%\Archives"

REM =====================================================================
REM SCRIPTS SQL
REM =====================================================================
set "SQMCMD_DIR="
set "SQL_CREATE=%proclib%\yhm_compare_0_create_tables.sql"
set "SQL_CREATE_STRUCT=%proclib%\yhm_compare_0_create_prc_structure.sql"
set "SQL_CREATE_DONN=%proclib%\yhm_compare_0_create_prc_donnees.sql"
set "SQL_RUN_STRUCT=%proclib%\yhm_compare_1_run_prc_structure.sql"
set "SQL_RUN_DONN=%proclib%\yhm_compare_2_run_prc_donnees.sql"
set "SQL_FLAG=%proclib%\yhm_compare_3_update_flag.sql"
set "SQL_SYNTH=%proclib%\yhm_compare_4_synthese.sql"

REM =====================================================================
REM HORODATAGE - FORMAT YYYYMMDD_HHMMSS
REM =====================================================================
set TS=%date:~6,4%%date:~3,2%%date:~0,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set TS=%TS: =0%

REM =====================================================================
REM CREATION DES REPERTOIRES
REM =====================================================================
if not exist "%ARCHIVE_DIR%" mkdir "%ARCHIVE_DIR%"

REM =====================================================================
REM NETTOYAGE REPERTOIRE LOGS (fichiers YHM_COMPARE_ du run precedent)
REM CORRIGE : filtre par prefixe pour ne pas impacter les autres jobs
REM =====================================================================
echo [INIT] Nettoyage des logs YHM_COMPARE precedents...
for %%F in ("%LOG_DIR%\YHM_COMPARE_*.*") do del "%%~fF" >nul 2>&1
echo   Fait - Logs YHM_COMPARE nettoyes

REM =====================================================================
REM INITIALISATION
REM CORRIGE : un fichier log distinct par etape
REM =====================================================================
set "GLOBAL_ERR_LOG=%LOG_DIR%\YHM_COMPARE_V4_V5_ERRORS_!TS!.log"
set "LOG_CREATE_TABLE=%LOG_DIR%\YHM_COMPARE_V4_V5_CREATE_TABLE_!TS!.log"
set "LOG_CREATE_STRUCT=%LOG_DIR%\YHM_COMPARE_V4_V5_CREATE_STRUCT_!TS!.log"
set "LOG_CREATE_DONN=%LOG_DIR%\YHM_COMPARE_V4_V5_CREATE_DONN_!TS!.log"
set "LOG_STRUCT=%LOG_DIR%\YHM_COMPARE_V4_V5_STRUCTURE_!TS!.log"
set "LOG_DONN=%LOG_DIR%\YHM_COMPARE_V4_V5_DONNEES_!TS!.log"
set "LOG_FLAG=%LOG_DIR%\YHM_COMPARE_V4_V5_FLAG_!TS!.log"
set "LOG_SYNTH=%LOG_DIR%\YHM_COMPARE_V4_V5_SYNTHESE_!TS!.log"

if exist "!GLOBAL_ERR_LOG!" del "!GLOBAL_ERR_LOG!" >nul 2>&1

set "NB_SUCCES=0"
set "NB_ECHEC=0"
set "RAPPORT_LIGNES="

echo ============================================================
echo  COMPARAISON V4 VS V5 (STRUCTURE + DONNEES) - !TS!
echo  Mode historisation : les runs precedents sont conserves
echo ============================================================

REM =====================================================================
REM ETAPE 1 : CREATION / VERIFICATION TABLE
REM =====================================================================
echo [ETAPE 1/7] Creation / verification ORT_ECART_DETAILS_V4_V5

sqlcmd -S %Server% -d %DataBase% -E -b -i "%SQL_CREATE%" >> "!LOG_CREATE_TABLE!" 2>&1
if errorlevel 1 (
    echo   Echec - Erreur creation table
    set "RC=20"
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR ETAPE 1 - Creation table. RC=20
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 1 - Erreur creation de ORT_ECART_DETAILS_V4_V5^|"
    goto FIN
)
findstr /I /C:"Msg " /C:"Level " /C:"Incorrect" /C:"Cannot" /C:"Error" "!LOG_CREATE_TABLE!" >nul 2>&1
if not errorlevel 1 (
    echo   Echec - Erreur SQL detectee dans le log creation
    set "RC=20"
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR SQL ETAPE 1 - Detectee dans le log. RC=20
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 1 - Erreur SQL creation / verification ORT_ECART_DETAILS_V4_V5^|"
    goto FIN
)
set /a NB_SUCCES+=1
echo   Fait - Table prete
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 1 - Tables creees / verifiees^|"

REM =====================================================================
REM ETAPE 2 : CREATION PROCEDURE STRUCTURE
REM =====================================================================
echo [ETAPE 2/7] Creation procedure ORT_PRC_COMPARE_STRUCTURE_V4_V5...

sqlcmd -S %Server% -d %DataBase% -E -b -i "%SQL_CREATE_STRUCT%" >> "!LOG_CREATE_STRUCT!" 2>&1
if errorlevel 1 (
    echo   Echec - Erreur creation proc STRUCTURE
    set "RC=20"
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR ETAPE 2 - Creation proc STRUCTURE. RC=20
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 2 - Erreur creation proc ORT_PRC_COMPARE_STRUCTURE_V4_V5^|"
    goto FIN
)
findstr /I /C:"Msg " /C:"Level " /C:"Incorrect" /C:"Cannot" /C:"Error" "!LOG_CREATE_STRUCT!" >nul 2>&1
if not errorlevel 1 (
    echo   Echec - Erreur SQL detectee dans la creation proc STRUCTURE
    set "RC=20"
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR SQL ETAPE 2 - Detectee dans le log. RC=20
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 2 - Erreur SQL creation proc ORT_PRC_COMPARE_STRUCTURE_V4_V5^|"
    goto FIN
)
set /a NB_SUCCES+=1
echo   Fait - Procedure STRUCTURE prete
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 2 - Proc ORT_PRC_COMPARE_STRUCTURE_V4_V5 creee^|"

REM =====================================================================
REM ETAPE 3 : EXECUTION COMPARAISON STRUCTURE
REM =====================================================================
echo [ETAPE 3/7] Execution comparaison STRUCTURE...

sqlcmd -S %Server% -d %DataBase% -E -b ^
  -v TS="%TS%" ^
  -i "%SQL_RUN_STRUCT%" >> "!LOG_STRUCT!" 2>&1

if errorlevel 1 (
    echo   Echec - Erreur execution comparaison STRUCTURE
    set "RC=20"
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR ETAPE 3 - Exec STRUCTURE. RC=20
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 3 - Erreur execution comparaison STRUCTURE^|"
    goto FIN
)
findstr /I /C:"Msg " /C:"Level " /C:"Incorrect" /C:"Cannot" /C:"Error" "!LOG_STRUCT!" >nul 2>&1
if not errorlevel 1 (
    echo   Echec - Erreur SQL detectee dans l'execution STRUCTURE
    set "RC=20"
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR SQL ETAPE 3 - Detectee dans le log. RC=20
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 3 - Erreur SQL execution comparaison STRUCTURE^|"
    goto FIN
)
set /a NB_SUCCES+=1
echo   Fait - Comparaison STRUCTURE terminee
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 3 - Comparaison STRUCTURE executee^|"

REM =====================================================================
REM ETAPE 4 : CREATION PROCEDURE DONNEES
REM =====================================================================
echo [ETAPE 4/7] Creation procedure ORT_PRC_COMPARE_DONNEES_V4_V5...

sqlcmd -S %Server% -d %DataBase% -E -b -i "%SQL_CREATE_DONN%" >> "!LOG_CREATE_DONN!" 2>&1
if errorlevel 1 (
    echo   Echec - Erreur creation proc DONNEES
    set "RC=20"
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR ETAPE 4 - Creation proc DONNEES. RC=20
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 4 - Erreur creation proc ORT_PRC_COMPARE_DONNEES_V4_V5^|"
    goto FIN
)
findstr /I /C:"Msg " /C:"Level " /C:"Incorrect" /C:"Cannot" /C:"Error" "!LOG_CREATE_DONN!" >nul 2>&1
if not errorlevel 1 (
    echo   Echec - Erreur SQL detectee dans la creation proc DONNEES
    set "RC=20"
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR SQL ETAPE 4 - Detectee dans le log. RC=20
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 4 - Erreur SQL creation proc ORT_PRC_COMPARE_DONNEES_V4_V5^|"
    goto FIN
)
set /a NB_SUCCES+=1
echo   Fait - Procedure DONNEES prete
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 4 - Proc ORT_PRC_COMPARE_DONNEES_V4_V5 creee^|"

REM =====================================================================
REM ETAPE 5 : EXECUTION COMPARAISON DONNEES
REM =====================================================================
echo [ETAPE 5/7] Execution comparaison DONNEES...

sqlcmd -S %Server% -d %DataBase% -E -b ^
  -v TS="%TS%" ^
  -i "%SQL_RUN_DONN%" >> "!LOG_DONN!" 2>&1

if errorlevel 1 (
    echo   Echec - Erreur execution comparaison DONNEES
    set "RC=20"
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR ETAPE 5 - Exec DONNEES. RC=20
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 5 - Erreur execution comparaison DONNEES^|"
    goto FIN
)
findstr /I /C:"Msg " /C:"Level " /C:"Incorrect" /C:"Cannot" /C:"Error" "!LOG_DONN!" >nul 2>&1
if not errorlevel 1 (
    echo   Echec - Erreur SQL detectee dans l'execution DONNEES
    set "RC=20"
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR SQL ETAPE 5 - Detectee dans le log. RC=20
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 5 - Erreur SQL execution comparaison DONNEES^|"
    goto FIN
)
set /a NB_SUCCES+=1
echo   Fait - Comparaison DONNEES terminee
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 5 - Comparaison DONNEES executee^|"

REM =====================================================================
REM ETAPE 6 : MISE A JOUR DES FLAGS
REM =====================================================================
echo [ETAPE 6/7] Mise a jour flag_ecart_explique...

sqlcmd -S %Server% -d %DataBase% -E -b -i "%SQL_FLAG%" >> "!LOG_FLAG!" 2>&1
if errorlevel 1 (
    echo   Echec - Erreur mise a jour flag_ecart_explique
    set "RC=20"
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR ETAPE 6 - Mise a jour flag. RC=20
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 6 - Erreur mise a jour flag_ecart_explique^|"
    goto FIN
)
findstr /I /C:"Msg " /C:"Level " /C:"Incorrect" /C:"Cannot" /C:"Error" "!LOG_FLAG!" >nul 2>&1
if not errorlevel 1 (
    echo   Echec - Erreur SQL detectee dans la mise a jour des flags
    set "RC=20"
    set "HAS_ERROR=1"
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR SQL ETAPE 6 - Detectee dans le log. RC=20
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 6 - Erreur SQL mise a jour flag_ecart_explique^|"
    goto FIN
)
set /a NB_SUCCES+=1
echo   Fait - Flags mis a jour
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 6 - flag_ecart_explique mis a jour^|"

REM =====================================================================
REM ETAPE 7 : RAPPORT DE SYNTHESE
REM =====================================================================
echo [ETAPE 7/7] Rapport de synthese...

sqlcmd -S %Server% -d %DataBase% -E -b -i "%SQL_SYNTH%" >> "!LOG_SYNTH!" 2>&1
if errorlevel 1 (
    echo   Echec - Erreur rapport de synthese ^(non bloquant^)
    set /a NB_ECHEC+=1
    >> "!GLOBAL_ERR_LOG!" echo ERREUR ETAPE 7 - Rapport de synthese.
    set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [ECHEC] - ETAPE 7 - Erreur rapport de synthese^|"
    goto FIN
)
set /a NB_SUCCES+=1
echo   Fait - Rapport de synthese genere : !LOG_SYNTH!
set "RAPPORT_LIGNES=!RAPPORT_LIGNES!  [SUCCES] - ETAPE 7 - Rapport de synthese genere^|"

REM =====================================================================
REM FIN
REM =====================================================================
:FIN

REM =====================================================================
REM NETTOYAGE REPERTOIRE LOGS (fichiers YHM_COMPARE_ vide - Taille=0)
REM CORRIGE : filtre par prefixe pour ne pas impacter les autres jobs
REM =====================================================================
for %%L in ("%LOG_DIR%\YHM_COMPARE_*.log") do (
    if %%~zL==0 del "%%~fL" >nul 2>&1
)

REM =====================================================================
REM ARCHIVAGE ZIP (consolide - un seul passage)
REM =====================================================================
echo [ZIP] Creation de l'archive ZIP...

set "ZIP_RUN="
if "!HAS_ERROR!"=="1" (
    set "ZIP_RUN=%ARCHIVE_DIR%\YHM_COMPARE_ERREURS_!TS!.zip"
) else (
    set "ZIP_RUN=%ARCHIVE_DIR%\YHM_COMPARE_LOGS_!TS!.zip"
)

set "HAS_LOGS=0"
for %%F in ("%LOG_DIR%\YHM_COMPARE_*.*") do set "HAS_LOGS=1"
if "!HAS_LOGS!"=="1" (
	set INZIP=!LOG_DIR!\YHM_COMPARE_*.*
	echo !INZIP!
	rem call %proclib%\7za.exe a -tzip !ZIP_RUN! !INZIP! -sdel
	call %proclib%\7za.exe a -tzip !ZIP_RUN! !INZIP! -sdel	
    rem powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
    rem     "$f = Get-ChildItem -Path '%LOG_DIR%' -Filter 'YHM_COMPARE_*'; " ^
    rem    "if ($f) { Compress-Archive -Path $f.FullName -DestinationPath '!ZIP_RUN!' -Force; $f | Remove-Item -Force }"
    rem    "if ($f) { Compress-Archive -Path $f.FullName -DestinationPath '!ZIP_RUN!' -Force"
    if not errorlevel 1 echo   Fait - ZIP : !ZIP_RUN!
)

echo ================================================================
echo  SYNTHESE
echo    Succes : !NB_SUCCES!
echo    Echecs : !NB_ECHEC!
echo    Code retour : !RC!
echo ================================================================

if "!HAS_ERROR!"=="0" (
    echo  "Resultats dans : ORT_ECART_DETAILS_V4_V5"
)

REM -----------------------------------------------------------------
REM IMPORTANT : si des erreurs ont ete detectees mais RC est reste a 0
REM on force RC=20 (erreur fonctionnelle)
REM -----------------------------------------------------------------
if "!HAS_ERROR!"=="1" if "!RC!"=="0" set "RC=20"

REM =========================================================================
REM ENVOI DU MAIL HTML
REM =========================================================================

set "MAIL_STATUS=SUCCES"
if "!RC!"=="20" set "MAIL_STATUS=ERREUR"

REM Construire option -Attachments uniquement si le zip existe
set "ATT_OPT="
if not "!ZIP_RUN!"=="" if exist "!ZIP_RUN!" set "ATT_OPT=-Attachments ""!ZIP_RUN!"""

REM Appel du module HTML
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass ^
  -File "%SENDNOTIF_HTML%" ^
  -ConfigFile "%MAIL_CONFIG%" ^
  -Status "!MAIL_STATUS!" ^
  -NomJob "COMPARAISON_V4_V5" ^
  -Horodatage "!TS!" ^
  -KeyValues "Base=%DataBase%;Serveur=%Server%" ^
  -Etapes "!RAPPORT_LIGNES!" ^
  %ATT_OPT%

if errorlevel 1 (
    echo [ERR] Erreur lors de l'envoi du mail
)

exit /b !RC!
