# Product Specifications

## MVP Features

### Agency Dashboard
- Create property listings
- Edit property listings
- Upload property photos
- Generate AI descriptions

### Public Agency Page
URL format:
/[agencySlug]

Displays:
- Agency information
- Listings
- WhatsApp contact button

### Smart Listing Form
Fields:
- title
- price
- surface
- wilaya
- commune
- document type
- property type
- features