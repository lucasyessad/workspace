# UI Design

Color palette:
#1a202c (Dark Blue)
#d4af37 (Gold)
#f7fafc (Off White)

Style:
Minimal luxury interface.

Mobile first design.