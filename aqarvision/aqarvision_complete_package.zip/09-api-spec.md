POST /api/generate-description

Request:
{
 title,
 surface,
 location,
 features
}

Response:
{
 description_fr,
 description_ar
}