insert into wilayas(id, code, nom_fr, nom_ar) values
(1,'01','Adrar','أدرار'),
(2,'02','Chlef','الشلف'),
(3,'03','Laghouat','الأغواط'),
(4,'04','Oum El Bouaghi','أم البواقي'),
(5,'05','Batna','باتنة'),
(6,'06','Bejaia','بجاية'),
(7,'07','Biskra','بسكرة'),
(8,'08','Bechar','بشار');