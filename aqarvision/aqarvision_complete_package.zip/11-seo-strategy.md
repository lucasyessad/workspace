SEO Strategy:

- SSR pages
- Structured data
- Clean URLs
- Optimized images