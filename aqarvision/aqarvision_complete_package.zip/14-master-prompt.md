You are a senior engineer building a SaaS called AqarVision.

Stack:
Next.js
TypeScript
Tailwind
Supabase

Build:
- authentication
- listings dashboard
- public agency page
- AI description generator