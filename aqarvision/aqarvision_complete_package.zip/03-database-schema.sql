create table profiles(
 id uuid primary key,
 agency_name text,
 phone text,
 wilaya int,
 verified boolean default false,
 slug text unique
);

create table listings(
 id uuid primary key,
 agent_id uuid references profiles(id),
 title text,
 description text,
 price numeric,
 surface numeric,
 property_type text,
 document_status text,
 wilaya int,
 commune int,
 photos text[]
);