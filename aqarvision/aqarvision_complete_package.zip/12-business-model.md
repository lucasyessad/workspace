Pricing:

Starter:
15€/month

Pro:
35€/month

Enterprise:
Custom pricing