# Technical Architecture

Frontend:
Next.js + TypeScript + Tailwind

Backend:
Supabase

Database:
PostgreSQL

Authentication:
Supabase Auth

Images:
Cloudinary CDN

AI:
OpenAI API

Deployment:
Vercel