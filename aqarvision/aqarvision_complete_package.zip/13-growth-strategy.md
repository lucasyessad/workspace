Growth Strategy:

1. Target agencies in Algiers
2. Offer free trial
3. Partner with real estate networks
4. SEO for property searches