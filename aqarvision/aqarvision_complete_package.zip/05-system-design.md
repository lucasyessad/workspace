# System Design

User -> Next.js App -> API Routes -> Supabase DB

Images -> Cloudinary CDN

AI -> OpenAI API

Public pages rendered with SSR for SEO.